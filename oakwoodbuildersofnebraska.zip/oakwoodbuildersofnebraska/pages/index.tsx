import Head from "next/head";
import Image from "next/image";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { MoveRight } from "lucide-react";
import { motion } from "framer-motion";

/* truncated for brevity - full component content exists in the canvas */
export default function OakwoodBuilders() {
  return (
    <>
      <Head>
        <title>Oakwood Builders | Custom Homes in Southeastern Nebraska</title>
        ...
      </Head>
      ...
    </>
  );
}
